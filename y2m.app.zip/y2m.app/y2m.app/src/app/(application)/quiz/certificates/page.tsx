'use client';
import { useState, useEffect } from 'react';
import CertificateCard from '@/components/certificate/certificatecard'; // Import the updated component
import MainSection from '@/components/common/main-section';
import MainSectionBody from '@/components/common/main-section-body';
import Title from '@/components/common/title';
import { useUser } from '@auth0/nextjs-auth0/client';

interface CertificateData {
  id: number;
  issuedAt: string;
  assessmentTitle: string;
  userName: string; // Ensure this matches your certificate data structure
  resultId: string; // Include resultId in the fetched data
}

const CertificatesPage = () => {
  const { user, isLoading } = useUser(); // Get the user information and loading state from Auth0
  const [certificates, setCertificates] = useState<CertificateData[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function fetchCertificates() {
      if (!user?.sub) return; // Ensure the user is authenticated and has a userId (sub)

      try {
        const response = await fetch(`/api/certificates?userId=${user.sub}`);
        const data = await response.json();

        if (data.success) {
          // Ensure that if userName is missing from the API, we use the logged-in user's name
          const formattedCertificates = data.certificates.map((cert: CertificateData) => ({
            ...cert,
            userName: cert.userName || user?.name || 'Anonymous', // Fallback to user.name from Auth0 if missing
          }));
          setCertificates(formattedCertificates); // Ensure the structure matches your API response
        } else {
          console.error('Failed to fetch certificates:', data.message);
        }
      } catch (error) {
        console.error('Error fetching certificates:', error);
      } finally {
        setLoading(false);
      }
    }

    if (user?.sub) {
      fetchCertificates();
    }
  }, [user?.sub]);

  if (isLoading || loading) return <div>Loading certificates...</div>;

  if (!user) return <div>Please log in to view your certificates.</div>; // Handle the case when user is not logged in

  return (
    <div className="mx-auto min-h-screen max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <MainSection>
        <MainSectionBody className="space-y-6">
          <div className="space-y-6 md:w-1/2">
            <Title>Your Certificates</Title>
          </div>
          <h2>
            Here are the certificates you have earned. Download and showcase your achievements!
          </h2>
        </MainSectionBody>
      </MainSection>

      {/* Display Certificates List in a grid */}
      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        {certificates.length === 0 ? (
          <p>No certificates available at the moment.</p>
        ) : (
          certificates.map((certificate) => (
            <CertificateCard
              key={certificate.id}
              title={certificate.assessmentTitle} // Display the assessment title
              issuedAt={certificate.issuedAt} // Display the issue date
              userName={certificate.userName} // Pass the user's name from the certificate data or fallback
              resultId={certificate.resultId} // Include resultId if needed in the card component
            />
          ))
        )}
      </div>
    </div>
  );
};

export default CertificatesPage;
