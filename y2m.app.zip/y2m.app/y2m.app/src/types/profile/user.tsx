import { User as DBUser } from '../db';

export interface User extends DBUser {}
